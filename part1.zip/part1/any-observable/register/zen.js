'use strict';
require('../register')('zen-observable', {Observable: require('zen-observable')});
