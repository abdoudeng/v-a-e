## v4.8.1

https://github.com/sass/node-sass/releases/tag/v4.8.1

## v4.8.0

https://github.com/sass/node-sass/releases/tag/v4.8.0

## v4.7.2

https://github.com/sass/node-sass/releases/tag/v4.7.2

## v4.7.1

https://github.com/sass/node-sass/releases/tag/v4.7.1

## v4.7.0

https://github.com/sass/node-sass/releases/tag/v4.7.0

## v4.6.1

https://github.com/sass/node-sass/releases/tag/v4.6.1

## v4.6.0

https://github.com/sass/node-sass/releases/tag/v4.6.0

## v4.5.0

https://github.com/sass/node-sass/releases/tag/v4.5.0

## v4.4.0

https://github.com/sass/node-sass/releases/tag/v4.4.0

## v4.3.0

https://github.com/sass/node-sass/releases/tag/v4.3.0

## v4.2.0

https://github.com/sass/node-sass/releases/tag/v4.2.0

## v4.1.1

https://github.com/sass/node-sass/releases/tag/v4.1.1

## v4.1.0

https://github.com/sass/node-sass/releases/tag/v4.1.0

## v4.0.0

https://github.com/sass/node-sass/releases/tag/v4.0.0

## v3.13.1

https://github.com/sass/node-sass/releases/tag/v3.13.1

## v3.13.0

https://github.com/sass/node-sass/releases/tag/v3.13.0

## v3.12.5

https://github.com/sass/node-sass/releases/tag/v3.12.5

## v3.12.4

https://github.com/sass/node-sass/releases/tag/v3.12.4

## v3.12.3

https://github.com/sass/node-sass/releases/tag/v3.12.3

## v3.12.2

https://github.com/sass/node-sass/releases/tag/v3.12.2

## v3.12.1

https://github.com/sass/node-sass/releases/tag/v3.12.1

## v3.12.0

https://github.com/sass/node-sass/releases/tag/v3.12.0

## v3.11.3

https://github.com/sass/node-sass/releases/tag/v3.11.3

## v3.11.2

https://github.com/sass/node-sass/releases/tag/v3.11.2

## v3.11.1

https://github.com/sass/node-sass/releases/tag/v3.11.1

## v3.11.0

https://github.com/sass/node-sass/releases/tag/v3.11.0

## v3.10.1

https://github.com/sass/node-sass/releases/tag/v3.10.1

## v3.10.0

https://github.com/sass/node-sass/releases/tag/v3.10.0

## v3.9.3

https://github.com/sass/node-sass/releases/tag/v3.9.3

## v3.9.2

(removed)

## v3.9.1

(removed)

## v3.9.0

https://github.com/sass/node-sass/releases/tag/v3.9.0

## v3.8.0

https://github.com/sass/node-sass/releases/tag/v3.8.0

## v3.7.0

https://github.com/sass/node-sass/releases/tag/v3.7.0

## v3.6.0

https://github.com/sass/node-sass/releases/tag/v3.6.0

## v3.5.3

https://github.com/sass/node-sass/releases/tag/v3.5.3

## v3.5.2

https://github.com/sass/node-sass/releases/tag/v3.5.2

## v3.5.1

https://github.com/sass/node-sass/releases/tag/v3.5.1

## v3.5.0

(removed)

## v3.4.2

https://github.com/sass/node-sass/releases/tag/v3.4.2

## v3.4.1

https://github.com/sass/node-sass/releases/tag/v3.4.1

## v3.4.0

https://github.com/sass/node-sass/releases/tag/v3.4.0

## v3.3.3

https://github.com/sass/node-sass/releases/tag/v3.3.3

## v3.3.2

https://github.com/sass/node-sass/releases/tag/v3.3.2

## v3.3.1

https://github.com/sass/node-sass/releases/tag/v3.3.1

## v3.3.0

https://github.com/sass/node-sass/releases/tag/v3.3.0

## v3.2.0

https://github.com/sass/node-sass/releases/tag/v3.2.0

## v3.1.2

https://github.com/sass/node-sass/releases/tag/v3.1.2

## v3.1.1

https://github.com/sass/node-sass/releases/tag/v3.1.1

## v3.1.0

https://github.com/sass/node-sass/releases/tag/v3.1.0

## v3.0.0

https://github.com/sass/node-sass/releases/tag/v3.0.0

